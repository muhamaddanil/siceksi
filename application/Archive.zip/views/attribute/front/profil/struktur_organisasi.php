  <section class="ftco-section">
      <div class="container">
        
          
          <img src="<?php echo site_url()?>assets/img/struktur_organisasi.png">
          

          

          
          
          
        
        
      </div>
    </section>
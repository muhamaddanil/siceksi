<footer class="ftco-footer ftco-bg-dark ftco-section">
    <div class="container">
      <div class="row">
        <div class="col-md-12 text-center">
          <p>
            Copyright &copy;
            <script type="6dc0c0326a0f8fb556bf60d5-text/javascript">
              document.write(new Date().getFullYear());
            </script> All rights reserved| Create By <i class="icon-heart text-danger" aria-hidden="true"></i> - <a href="" target="_blank">FITNAWATI 017</a>
          </p>
        </div>
      </div>
    </div>
  </footer>
  <div id="ftco-loader" class="show fullscreen">
    <svg class="circular" width="48px" height="48px">
      <circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee" />
      <circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00" />
    </svg>
  </div>
  <script src="<?php echo base_url() ?>assets/front/js/jquery.min.js" type="6dc0c0326a0f8fb556bf60d5-text/javascript"></script>
  <script src="<?php echo base_url() ?>assets/front/js/jquery-migrate-3.0.1.min.js" type="6dc0c0326a0f8fb556bf60d5-text/javascript"></script>
  <script src="<?php echo base_url() ?>assets/front/js/popper.min.js" type="6dc0c0326a0f8fb556bf60d5-text/javascript"></script>
  <script src="<?php echo base_url() ?>assets/front/js/bootstrap.min.js" type="6dc0c0326a0f8fb556bf60d5-text/javascript"></script>
  <script src="<?php echo base_url() ?>assets/front/js/jquery.easing.1.3.js" type="6dc0c0326a0f8fb556bf60d5-text/javascript"></script>
  <script src="<?php echo base_url() ?>assets/front/js/jquery.waypoints.min.js" type="6dc0c0326a0f8fb556bf60d5-text/javascript"></script>
  <script src="<?php echo base_url() ?>assets/front/js/jquery.stellar.min.js" type="6dc0c0326a0f8fb556bf60d5-text/javascript"></script>
  <script src="<?php echo base_url() ?>assets/front/js/owl.carousel.min.js" type="6dc0c0326a0f8fb556bf60d5-text/javascript"></script>
  <script src="<?php echo base_url() ?>assets/front/js/jquery.magnific-popup.min.js" type="6dc0c0326a0f8fb556bf60d5-text/javascript"></script>
  <script src="<?php echo base_url() ?>assets/front/js/aos.js" type="6dc0c0326a0f8fb556bf60d5-text/javascript"></script>
  <script src="<?php echo base_url() ?>assets/front/js/jquery.animateNumber.min.js" type="6dc0c0326a0f8fb556bf60d5-text/javascript"></script>
  <script src="<?php echo base_url() ?>assets/front/js/scrollax.min.js" type="6dc0c0326a0f8fb556bf60d5-text/javascript"></script>
  <script src="<?php echo base_url() ?>assets/front/js/main.js" type="6dc0c0326a0f8fb556bf60d5-text/javascript"></script>
  <script src="https://ajax.cloudflare.com/cdn-cgi/scripts/7089c43e/cloudflare-static/rocket-loader.min.js" data-cf-settings="6dc0c0326a0f8fb556bf60d5-|49" defer=""></script>

</body>

</html>